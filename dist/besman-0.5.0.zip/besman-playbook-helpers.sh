#!/usr/bin/env bash

function __besman_generate_osar
{
    python3 $BESMAN_DIR/scripts/besman-generate-osar.py
}